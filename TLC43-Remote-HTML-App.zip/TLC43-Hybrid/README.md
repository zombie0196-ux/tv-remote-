# TLC43 Remote (IR)

Android app (HTML interface + phone IR blaster) built from TLC43DI25.cod (IC uPD6121G = NEC protocol,
address 0x08, 38 kHz). 51 keys, see codes.csv.

Needs a phone with an IR blaster (e.g. many Xiaomi / Redmi / some Huawei,
Honor, older Samsung / LG / HTC models).

## Build the APK without installing anything
1. Create a free GitHub account, make a new repository, upload ALL files of
   this folder (keep the .github folder).
2. Open the Actions tab -> "Build APK" -> wait about 3 minutes.
3. Open the finished run -> Artifacts -> download TLC43-Remote-apk (zip
   containing app-debug.apk). Copy it to the phone and install it.

## Or with Android Studio
File -> Open this folder -> Build -> Build APK(s).
