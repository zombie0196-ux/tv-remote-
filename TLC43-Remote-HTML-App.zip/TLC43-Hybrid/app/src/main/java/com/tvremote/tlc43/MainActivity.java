package com.tvremote.tlc43;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/** Shows assets/index.html and sends keys through the phone's IR blaster (NEC, addr 0x08, 38 kHz). */
public class MainActivity extends Activity {

    private static final int ADDRESS = 0x08;
    private static final int CARRIER_HZ = 38000;
    private ConsumerIrManager ir;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#14161A"));
        web.getSettings().setJavaScriptEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private class Bridge {
        @JavascriptInterface
        public boolean hasIr() {
            return ir != null && ir.hasIrEmitter();
        }

        @JavascriptInterface
        public void sendCode(int cmd) {
            if (hasIr()) ir.transmit(CARRIER_HZ, nec(ADDRESS, cmd & 0xFF));
        }
    }

    static int[] nec(int addr, int cmd) {
        int frame = (addr & 0xFF) | ((~addr & 0xFF) << 8)
                  | ((cmd & 0xFF) << 16) | ((~cmd & 0xFF) << 24);
        int[] p = new int[67];
        int i = 0;
        p[i++] = 9000;
        p[i++] = 4500;
        for (int b = 0; b < 32; b++) {
            p[i++] = 560;
            p[i++] = ((frame >> b) & 1) == 1 ? 1690 : 560;
        }
        p[i++] = 560;
        return p;
    }
}
